//$("#product-image").imagezoomsl({
//	zoomrange: [1, 12],
//	zoomstart: 4,
//	innerzoom: true,
//	magnifierborder: "none"
//});
